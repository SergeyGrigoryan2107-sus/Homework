// Плавный скролл для якорей меню
document.querySelectorAll('.nav-links a').forEach(link => {
    link.addEventListener('click', function(e) {
        const targetId = this.getAttribute('href');
        if (targetId && targetId !== '#') {
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                e.preventDefault();
                targetElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
                targetElement.classList.add('highlight');
                setTimeout(() => targetElement.classList.remove('highlight'), 800);
            }
        }
    });
});

// Активное меню при скролле
const sections = document.querySelectorAll('section');
const navItems = document.querySelectorAll('.nav-links a');
function setActiveLink() {
    let current = '';
    const scrollPos = window.scrollY + 100;
    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.clientHeight;
        if (scrollPos >= sectionTop && scrollPos < sectionTop + sectionHeight) {
            current = section.getAttribute('id');
        }
    });
    navItems.forEach(item => {
        const href = item.getAttribute('href').substring(1);
        if (href === current) {
            item.style.color = '#c86a4a';
            item.style.fontWeight = '700';
        } else {
            item.style.color = '#2c2418';
            item.style.fontWeight = '500';
        }
    });
}
window.addEventListener('scroll', setActiveLink);
window.addEventListener('load', setActiveLink);

// Добавим небольшую анимацию для кнопок (необязательно)
document.addEventListener('DOMContentLoaded', () => {
    // Кнопка добавления продукта будет инициализирована в PyScript, но можно добавить запасной слушатель
    console.log("Site loaded, PyScript will handle product logic.");
})