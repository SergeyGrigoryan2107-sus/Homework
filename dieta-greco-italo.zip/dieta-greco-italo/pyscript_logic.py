import matplotlib
matplotlib.use('agg')
import matplotlib.pyplot as plt
from pyodide.ffi import create_proxy
from js import document, console
import json

# База продуктов (на 100г)
PRODUCTS_DB = {
    "greek_yogurt": {"name": "Греческий йогурт", "kcal": 59, "protein": 10.0, "fat": 0.4, "carbs": 3.6, "fiber": 0.0, "extra": "Кальций, пробиотики"},
    "olive_oil": {"name": "Оливковое масло", "kcal": 884, "protein": 0.0, "fat": 100.0, "carbs": 0.0, "fiber": 0.0, "extra": "Полифенолы, Омега-9"},
    "sardines": {"name": "Сардины", "kcal": 208, "protein": 24.6, "fat": 11.5, "carbs": 0.0, "fiber": 0.0, "extra": "Омега-3, витамин D"},
    "horta_greens": {"name": "Листовая зелень (хорта)", "kcal": 28, "protein": 2.9, "fat": 0.4, "carbs": 4.3, "fiber": 2.7, "extra": "Железо, антиоксиданты"},
    "lemon": {"name": "Лимон", "kcal": 29, "protein": 1.1, "fat": 0.3, "carbs": 9.3, "fiber": 2.8, "extra": "Витамин С, лимоноиды"},
    "chickpeas": {"name": "Нут вареный", "kcal": 139, "protein": 8.9, "fat": 2.6, "carbs": 22.5, "fiber": 7.6, "extra": "Фолат, марганец"},
    "feta_cheese": {"name": "Фета", "kcal": 264, "protein": 14.2, "fat": 21.3, "carbs": 4.1, "fiber": 0.0, "extra": "Кальций, фосфор"},
    "tomatoes": {"name": "Помидоры черри", "kcal": 18, "protein": 0.9, "fat": 0.2, "carbs": 3.9, "fiber": 1.2, "extra": "Ликопин, калий"}
}

food_log = []  # список добавленных продуктов

def update_table_and_chart(*args):
    tbody = document.getElementById("foodLogBody")
    tbody.innerHTML = ""
    total_kcal = 0.0
    total_protein = 0.0
    total_fat = 0.0
    total_carbs = 0.0
    total_fiber = 0.0
    extra_set = set()
    
    for idx, item in enumerate(food_log):
        prod_id = item["id"]
        grams = item["grams"]
        prod = PRODUCTS_DB[prod_id]
        factor = grams / 100.0
        kcal = prod["kcal"] * factor
        protein = prod["protein"] * factor
        fat = prod["fat"] * factor
        carbs = prod["carbs"] * factor
        fiber = prod["fiber"] * factor
        total_kcal += kcal
        total_protein += protein
        total_fat += fat
        total_carbs += carbs
        total_fiber += fiber
        extra_set.add(prod["extra"])
        
        row = tbody.insertRow()
        row.insertCell(0).innerText = prod["name"]
        row.insertCell(1).innerText = f"{grams:.0f}"
        row.insertCell(2).innerText = f"{kcal:.1f}"
        row.insertCell(3).innerText = f"{protein:.1f}"
        row.insertCell(4).innerText = f"{fat:.1f}"
        row.insertCell(5).innerText = f"{carbs:.1f}"
        row.insertCell(6).innerText = f"{fiber:.1f}"
        btn_cell = row.insertCell(7)
        del_btn = document.createElement("button")
        del_btn.innerText = "🗑️"
        del_btn.className = "delete-btn"
        del_btn.onclick = create_proxy(lambda e, i=idx: remove_item(i))
        btn_cell.appendChild(del_btn)
    
    document.getElementById("totalKcal").innerText = f"{total_kcal:.1f}"
    document.getElementById("totalProtein").innerText = f"{total_protein:.1f}"
    document.getElementById("totalFat").innerText = f"{total_fat:.1f}"
    document.getElementById("totalCarbs").innerText = f"{total_carbs:.1f}"
    document.getElementById("totalFiber").innerText = f"{total_fiber:.1f}"
    extra_text = ", ".join(list(extra_set)[:3]) if extra_set else "—"
    document.getElementById("extraInfo").innerHTML = f"🏛️ Полезные вещества: {extra_text}"
    
    # Построение круговой диаграммы (калории из БЖУ)
    cal_protein = total_protein * 4
    cal_fat = total_fat * 9
    cal_carbs = total_carbs * 4
    labels = []
    sizes = []
    colors = ['#7c8c3e', '#c86a4a', '#dbb87c']
    if cal_protein > 0:
        labels.append('Белки')
        sizes.append(cal_protein)
    if cal_fat > 0:
        labels.append('Жиры')
        sizes.append(cal_fat)
    if cal_carbs > 0:
        labels.append('Углеводы')
        sizes.append(cal_carbs)
    
    fig, ax = plt.subplots(figsize=(5, 4))
    if sum(sizes) == 0:
        ax.text(0.5, 0.5, "Добавьте продукты\nчтобы увидеть диаграмму", ha='center', va='center', fontsize=12)
        ax.axis('off')
    else:
        wedges, texts, autotexts = ax.pie(sizes, labels=labels, autopct='%1.1f%%', startangle=90, colors=colors[:len(labels)], textprops={'fontsize': 10})
        ax.set_title("Распределение калорий (БЖУ)", fontsize=12, fontfamily='Playfair Display')
        for autotext in autotexts:
            autotext.set_color('white')
            autotext.set_fontweight('bold')
    old_div = document.getElementById("matplotlib-figure")
    if old_div:
        old_div.innerHTML = ""
    display(fig, target="matplotlib-figure", append=False)
    plt.close(fig)

def remove_item(idx):
    if 0 <= idx < len(food_log):
        food_log.pop(idx)
        update_table_and_chart()

def add_product():
    select_elem = document.getElementById("productSelect")
    product_id = select_elem.value
    grams_elem = document.getElementById("gramsInput")
    try:
        grams = float(grams_elem.value)
        if grams <= 0:
            grams = 100
    except:
        grams = 100
    food_log.append({"id": product_id, "grams": grams})
    update_table_and_chart()

def setup_handlers():
    add_btn = document.getElementById("addButton")
    if add_btn:
        add_btn.addEventListener("click", create_proxy(add_product))
    # Начальные демо-продукты
    if len(food_log) == 0:
        food_log.append({"id": "greek_yogurt", "grams": 150})
        food_log.append({"id": "olive_oil", "grams": 10})
        food_log.append({"id": "tomatoes", "grams": 120})
        update_table_and_chart()

from pyodide.ffi import create_proxy
document.addEventListener("DOMContentLoaded", create_proxy(setup_handlers))